"""Reproducible release curation and checks. Writes outputs outside the dataset only.

Human provenance/selection and frozen fold allocation are explicit inputs, not inferred.
No operation changes the supplied dataset in place.
"""
from pathlib import Path
import argparse, collections, concurrent.futures, copy, csv, hashlib, io, itertools, json, re, uuid
import numpy as np
import nibabel as nib
import pydicom
from pydicom.dataset import Dataset, validate_file_meta
from pydicom.sequence import Sequence
from pydicom.uid import UID, PYDICOM_IMPLEMENTATION_UID

HERE = Path(__file__).resolve().parent
ANGLES = (60, 75, 90, 105, 120)
FINAL_LABEL = 'orientation-final-20261016'
NORMALIZATION_NOTE = ('Release UID and header normalization (2026-10-13); '
    'orientation-standardised presentation export. Original identifiers and header '
    'repairs: metadata/dicom_uid_mapping.csv. Pixel values unchanged.')

def digest(b): return hashlib.sha256(b).hexdigest()
def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        while b := f.read(8 * 1024 * 1024): h.update(b)
    return h.hexdigest()
def readcsv(p):
    with Path(p).open(encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))
def writecsv(p, rows, fields=None):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0]), lineterminator='\n')
        w.writeheader(); w.writerows(rows)
def savejson(p, obj):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
def safe(root, relative):
    p = (root / relative).resolve()
    if not p.is_relative_to(root.resolve()): raise ValueError('Path outside dataset: ' + relative)
    return p
def manifest(root):
    result = {}
    for l in (root / 'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
        h, n = l.split(maxsplit=1); n = n.lstrip('*').replace('\\', '/')
        if n in result: raise ValueError('Duplicate manifest path: ' + n)
        safe(root, n); result[n] = h
    return result
def expected_box(ref, board, target, shape):
    # Board units cm; 0.25 mm voxels. int() intentionally truncates toward zero.
    i = int(ref[0] + 40 * (target[0] - board[0]) - 60)
    j = int(ref[1] + 40 * (board[1] - target[1]) - 80)
    lo = (max(0, i), max(0, j), 160)
    hi = (min(shape[0], i + 120), min(shape[1], j + 160), min(shape[2], 300))
    dims = tuple(b - a for a, b in zip(lo, hi))
    if min(dims) <= 0: raise ValueError('Empty crop')
    return lo + dims
def coordinate_boxes(root, species, volume):
    base = root / 'source_cbct' / species / volume
    image = nib.load(base / (volume + '.nii.gz'))
    if not np.allclose(image.header.get_zooms()[:3], .25):
        raise ValueError('The published coordinate formula requires 0.25 mm voxels')
    lines = (base / (volume + '__coordinates.txt')).read_text(encoding='utf-8-sig').splitlines()
    vals = [list(map(float, l.split('#')[0].strip().replace(',', ' ').split()))
            for l in lines if l.split('#')[0].strip()]
    return [expected_box(vals[0], vals[1], v, image.shape) for v in vals[2:]]

def metadata(root, out, inputs):
    annotations = readcsv(inputs / 'release_record_inputs.csv')
    counts = collections.Counter(r['source_volume_id'] for r in annotations)
    boxes = {}; rows = []
    for a in annotations:
        volume = a['source_volume_id']; key = (a['species'], volume)
        if key not in boxes: boxes[key] = coordinate_boxes(root, *key)
        box = boxes[key][int(a['coordinate_target_index']) - 1]
        r = {k: a[k] for k in ('sample_id','data_group_id','species','anatomical_region',
             'animal_id','animal_linkage_status','specimen_id','source_volume_id','acquisition_day_id')}
        r.update(n_radiographs='5', nominal_angles_deg='60;75;90;105;120',
                 crop_index_in_source=a['crop_index_in_source'], n_crops_in_source=str(counts[volume]))
        r.update({f'crop_origin_{v}': str(box[i]) for i, v in enumerate('ijk')})
        r.update({f'retained_shape_{v}': str(box[i+3]) for i, v in enumerate('ijk')})
        r['is_boundary_clipped'] = str(box[3:] != (120,160,140)).lower(); rows.append(r)
    writecsv(out / 'metadata.csv', rows)
    old = readcsv(root / 'metadata/metadata.csv')
    savejson(out/'metadata_verification.json', dict(status='passed' if rows==old else 'different',
        records=len(rows), rows_identical=rows==old, provenance='Curated record selection and biological IDs are explicit input annotations. Crop boxes and derived fields recomputed from coordinate TXT and source headers.'))
    if rows != old: raise ValueError('Regenerated metadata differs from the published table')

def coordinates(root, out, inputs):
    records = readcsv(root/'metadata/metadata.csv'); boxes={}; rows=[]; used=collections.defaultdict(set)
    for r in records:
        key=(r['species'],r['source_volume_id'])
        if key not in boxes: boxes[key]=coordinate_boxes(root,*key)
        want=tuple(int(r[p+'_'+a]) for p in ('crop_origin','retained_shape') for a in 'ijk')
        hits=[i+1 for i,b in enumerate(boxes[key]) if b==want]
        if len(hits)!=1: raise ValueError('Non-unique coordinate target: '+r['sample_id'])
        if hits[0] in used[key]: raise ValueError('A coordinate target is assigned twice')
        used[key].add(hits[0])
        rows.append(dict(sample_id=r['sample_id'],source_volume_id=key[1],coordinate_target_index=hits[0],
                         retained_crop_index=r['crop_index_in_source'],index_shift=hits[0]-int(r['crop_index_in_source'])))
    writecsv(out/'coordinate_target_linkage.csv',rows)
    savejson(out/'coordinate_verification.json',dict(status='passed',records=len(rows),source_volumes=len(boxes),
        coordinate_targets=sum(map(len,boxes.values())),unused_targets=sum(len(v)-len(used[k]) for k,v in boxes.items()),
        shifted_records=sum(r['index_shift']!=0 for r in rows),scope='Unique coordinate-to-record box reproduction; does not measure anatomical registration error.'))

def crop_integrity(root,out,inputs,limit=0):
    grouped=collections.defaultdict(list)
    for r in readcsv(root/'metadata/metadata.csv'):grouped[(r['species'],r['source_volume_id'])].append(r)
    rows=[]
    for count,((species,volume),records) in enumerate(sorted(grouped.items()),1):
        source=nib.load(root/'source_cbct'/species/volume/(volume+'.nii.gz')).get_fdata(dtype=np.float32)
        for r in records:
            sid=r['sample_id'];p=root/'data'/species/r['data_group_id']/volume/sid/(sid+'__cbct_crop.nii.gz')
            im=nib.load(p);crop=im.get_fdata(dtype=np.float32)
            origin=[int(r['crop_origin_'+a]) for a in 'ijk'];shape=[int(r['retained_shape_'+a]) for a in 'ijk']
            box=source[tuple(slice(o,o+n) for o,n in zip(origin,shape))]
            if box.shape!=crop.shape or not np.isfinite(crop).all():raise ValueError('Crop shape/finite failure: '+sid)
            error=np.abs(box-crop);tolerance=abs(float(im.dataobj.slope))/2+.002
            rows.append(dict(sample_id=sid,source_volume_id=volume,max_abs_error=float(error.max()),
                mean_abs_error=float(error.mean()),tolerance=tolerance,within_quantization_tolerance=bool(error.max()<=tolerance)))
        del source
        if count%20==0:print('crop_integrity',count,'/',len(grouped),flush=True)
        if limit and count>=limit:break
    writecsv(out/'crop_integrity.csv',rows)
    ok=all(r['within_quantization_tolerance'] for r in rows)
    savejson(out/'crop_integrity_verification.json',dict(status='passed' if ok else 'failed',
        records=len(rows),source_volumes=count,full_release=not limit or count==len(grouped),
        scope='Scaled voxel reproduction within crop quantization tolerance; array-space boxes, not pixel-to-voxel anatomical registration.'))
    if not ok:raise ValueError('Crop intensity reproduction failed')

def partitions(root, out, inputs):
    records=readcsv(root/'metadata/metadata.csv'); parent={r['sample_id']:r['sample_id'] for r in records}
    def find(s):
        while parent[s]!=s: parent[s]=parent[parent[s]]; s=parent[s]
        return s
    for field in ('data_group_id','source_volume_id','specimen_id','animal_id'):
        seen={}
        for r in records:
            if field=='animal_id' and r['animal_linkage_status']!='verified': continue
            value=r[field]
            if not value: continue
            if value in seen: parent[find(r['sample_id'])]=find(seen[value])
            else: seen[value]=r['sample_id']
    comps=collections.defaultdict(list)
    for r in records: comps[find(r['sample_id'])].append(r)
    allocations={r['anchor_sample_id']:r for r in readcsv(inputs/'partition_allocation.csv')}
    units=[]; splits=[]; record_fold={}
    for comp in sorted(comps.values(),key=lambda c:min(r['sample_id'] for r in c)):
        anchor=min(r['sample_id'] for r in comp); alloc=allocations[anchor]
        val=lambda k: sorted({r[k] for r in comp if r[k]})
        animals=sorted({r['animal_id'] for r in comp if r['animal_linkage_status']=='verified'})
        status='verified' if all(r['animal_linkage_status']=='verified' for r in comp) else 'not_linkable'
        unit=dict(partition_unit_id=alloc['partition_unit_id'],n_groups=str(len(val('data_group_id'))),
            group_ids=';'.join(val('data_group_id')),species=';'.join(val('species')),
            anatomical_regions=';'.join(val('anatomical_region')),n_source_volumes=str(len(val('source_volume_id'))),
            n_specimens=str(len(val('specimen_id'))),n_verified_animals=str(len(animals)),animal_ids=';'.join(animals),
            animal_linkage_status=status,n_records=str(len(comp)),sample_id_min=anchor,sample_id_max=max(r['sample_id'] for r in comp))
        units.append(unit)
        splits.append({k:unit[k] for k in ('partition_unit_id',)}|dict(fold=alloc['fold'])|
                      {k:unit[k] for k in ('n_groups','n_source_volumes','n_records','animal_linkage_status')})
        for r in comp: record_fold[r['sample_id']]=alloc['fold']
    # Published row ordering is presentation only; component membership is independently rebuilt.
    units.sort(key=lambda r:r['partition_unit_id']); splits.sort(key=lambda r:(r['fold'],r['partition_unit_id']))
    writecsv(out/'partition_units.csv',units); writecsv(out/'example_5fold_by_partition_unit.csv',splits)
    overlap=[]
    for a,b in itertools.combinations(sorted(set(record_fold.values())),2):
        A=[r for r in records if record_fold[r['sample_id']]==a]; B=[r for r in records if record_fold[r['sample_id']]==b]
        x=dict(fold_pair=a+'-'+b)
        for field,label in (('data_group_id','shared_data_groups'),('source_volume_id','shared_source_volumes'),
                            ('animal_id','shared_verified_animals'),('specimen_id','shared_specimens')):
            values=lambda group:{r[field] for r in group if r[field] and (field!='animal_id' or r['animal_linkage_status']=='verified')}
            x[label]=str(len(values(A)&values(B)))
        overlap.append(x)
    writecsv(out/'partition_overlap_check.csv',overlap)
    compare=lambda new,path: {r['partition_unit_id']:r for r in new}=={r['partition_unit_id']:r for r in readcsv(root/path)}
    ok=compare(units,'metadata/partition_units.csv') and compare(splits,'metadata/splits/example_5fold_by_partition_unit.csv')
    savejson(out/'partition_verification.json',dict(status='passed' if ok else 'different',units=len(units),
        published_tables_match=ok,all_overlaps_zero=all(int(v)==0 for r in overlap for k,v in r.items() if k!='fold_pair'),
        allocation='Frozen published unit IDs/folds replayed from explicit allocation inputs; grouping computed from record links. No claim to recover an undocumented original randomization seed.'))
    if not ok or any(int(v) for r in overlap for k,v in r.items() if k!='fold_pair'): raise ValueError('Partition disagreement/overlap')

def file_tables(root, out, inputs, hash_mode='actual', workers=3):
    files=readcsv(root/'metadata/files.csv'); oldqc={r['relative_path']:r for r in readcsv(root/'metadata/file_qc.csv')}
    hashes=manifest(root); qc=[]
    def one(row):
        r=row.copy();p=safe(root,r['relative_path']);q=oldqc[r['relative_path']].copy()
        r['bytes']=q['bytes']=str(p.stat().st_size)
        r['sha256']=sha(p) if hash_mode=='actual' else hashes[r['relative_path']]
        q['readable']='true';q['error']=''
        if r['format']=='DICOM':
            ds=pydicom.dcmread(p);a=ds.pixel_array
            if not np.isfinite(a).all() or np.ptp(a)<=0: raise ValueError('Invalid pixels: '+str(p))
            q['data_dtype']=str(a.dtype);q['shape_i']=str(a.shape[0]);q['shape_j']=str(a.shape[1])
            # The published QC table uses detector-plane spacing, never object-space calibration.
            q['shape_k']='';spacing=list(getattr(ds,'ImagerPixelSpacing',getattr(ds,'PixelSpacing',[])))
            q['spacing_i']=str(float(spacing[0])) if spacing else ''
            q['spacing_j']=str(float(spacing[1])) if spacing else ''
            q['spacing_k']='';q['scl_slope']='';q['scl_inter']=''
        elif r['format']=='NIfTI':
            im=nib.load(p);q['data_dtype']=str(im.get_data_dtype())
            for ax,size,spacing in zip('ijk',im.shape,im.header.get_zooms()):
                q['shape_'+ax]=str(size);q['spacing_'+ax]=str(float(spacing))
            q['scl_slope']=str(float(im.dataobj.slope));q['scl_inter']=str(float(im.dataobj.inter))
        else:
            lines=p.read_text(encoding='utf-8-sig').splitlines()
            q['shape_i']=str(sum(bool(l.strip()) for l in lines))
        return r,q
    new=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for i,(r,q) in enumerate(pool.map(one,files),1):
            new.append(r);qc.append(q)
            if i%2000==0:print('file_tables',i,'/',len(files),flush=True)
    writecsv(out/'files.csv',new);writecsv(out/'file_qc.csv',qc)
    # Notes and stable identifier fields are source annotations, not inferred.
    savejson(out/'file_table_verification.json',dict(status='passed',files=len(new),hash_mode=hash_mode,
        actual_file_hashes_recomputed=hash_mode=='actual',preserved_fields='Stable IDs, roles and QC notes are read from the published annotation tables; bytes, hashes and imaging-header/decode checks are regenerated.'))

def dictionary(root,out,inputs):
    rows=readcsv(root/'metadata/data_dictionary.csv');index={(r['table'],r['field']):i for i,r in enumerate(rows)}
    for r in readcsv(inputs/'field_definitions.csv'):
        key=(r['table'],r['field'])
        if key in index:rows[index[key]]=r
        else:index[key]=len(rows);rows.append(r)
    writecsv(out/'data_dictionary.csv',rows)
    savejson(out/'dictionary_verification.json',dict(status='passed',definitions=len(rows),
        scope='Merge explicit curated field definitions; units and meanings are not inferred from values.'))

def checksums(root,out,inputs,workers=3):
    files=sorted(p for p in root.rglob('*') if p.is_file() and p!=root/'SHA256SUMS.txt')
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool: hashes=list(pool.map(sha,files))
    (out/'SHA256SUMS.txt').write_text(''.join(h+'  '+p.relative_to(root).as_posix()+'\n' for p,h in zip(files,hashes)),encoding='utf-8')
    old=manifest(root);new={p.relative_to(root).as_posix():h for p,h in zip(files,hashes)}
    bad=[n for n,h in new.items() if old.get(n)!=h]
    savejson(out/'checksum_verification.json',dict(status='passed' if old==new else 'different',
        files_hashed=len(new),missing_files=sorted(set(old)-set(new)),unlisted_files=sorted(set(new)-set(old)),mismatches=bad))
    if old!=new:raise ValueError('Manifest disagreement')

def final_uid(old_uid,pixel_hash):
    key='paired-radiograph-cbct:v1.0.0:'+FINAL_LABEL+':'+old_uid+':'+pixel_hash
    return '2.25.'+str(uuid.uuid5(uuid.NAMESPACE_URL,key).int)
def serialize(ds):
    f=io.BytesIO();pydicom.dcmwrite(f,ds,enforce_file_format=True);return f.getvalue()
def orientation(root,out,inputs):
    old=readcsv(root/'metadata/dicom_uid_mapping.csv');m={r['sample_id']:r for r in readcsv(root/'metadata/metadata.csv')}
    target_indices={r['sample_id']:int(r['coordinate_target_index']) for r in readcsv(inputs/'release_record_inputs.csv')}
    manual=readcsv(root/'validation/release_qc/manual_qc.csv');volume_rows={v:r for r in manual for v in r['source_volume_ids'].split(';')}
    provenance=[];events=[];finalsets=collections.defaultdict(set); staged=[]
    for row in old:
        rel=row['relative_path'];raw=safe(root,rel).read_bytes();ds=pydicom.dcmread(io.BytesIO(raw));pix=digest(ds.PixelData)
        sample=row['sample_id'];record=m[sample];volume=row['source_volume_id'];ordinal=target_indices[sample]
        historical_rounds={int(n) for n in volume_rows[volume]['orientation_rot180_rounds'].split(',') if n}
        historical=ordinal in historical_rounds;later=pix!=row['pixel_data_sha256']
        if later and digest(np.ascontiguousarray(np.rot90(ds.pixel_array,2)).tobytes())!=row['pixel_data_sha256']:
            raise ValueError('Unexplained pixel change: '+rel)
        if historical ^ later: finalsets[volume].add(ordinal)
        target=copy.deepcopy(ds);old_uid=row['new_sop_instance_uid']
        if later:
            target.SOPInstanceUID=final_uid(old_uid,pix);target.file_meta.MediaStorageSOPInstanceUID=target.SOPInstanceUID
            target.DerivationDescription=('Final orientation version 2026-10-16: 180 degree array rotation relative to the '
                '2026-10-13 normalized snapshot; pixel intensities unchanged. Retrospectively hash-verified, not a new '
                'anatomical review. See metadata/radiograph_provenance.csv and validation/orientation_events.csv.')
            source=Dataset();source.ReferencedSOPClassUID=ds.SOPClassUID;source.ReferencedSOPInstanceUID=old_uid
            target.SourceImageSequence=Sequence([source])
            validate_file_meta(target.file_meta,enforce_standard=True)
        payload=serialize(target) if later else raw
        if later:
            after=pydicom.dcmread(io.BytesIO(payload))
            if after.PixelData!=ds.PixelData or not np.array_equal(after.pixel_array,ds.pixel_array):raise ValueError('Pixel mutation')
            p=out/'dicom'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(payload)
            staged.append(dict(relative_path=rel,before_file_sha256=digest(raw),after_file_sha256=digest(payload),
                pixel_data_sha256=pix,old_instance_uid=str(ds.SOPInstanceUID),final_instance_uid=str(target.SOPInstanceUID),
                before_bytes=len(raw),after_bytes=len(payload),pixel_arrays_identical=True))
            events.append(dict(sample_id=sample,source_volume_id=volume,nominal_angle_deg=row['nominal_angle_deg'],
                retained_crop_index=record['crop_index_in_source'],coordinate_target_index=ordinal,operation='rot180',operation_timestamp='',operation_actor='',
                documented_on='2026-10-16',evidence='Inverse rot180 exactly matches historical normalized pixel SHA-256',
                historical_normalized_file_sha256=row['new_file_sha256'],historical_pixel_sha256=row['pixel_data_sha256'],
                final_pixel_sha256=pix,final_instance_uid=str(target.SOPInstanceUID),review_status='retrospective_transform_verification_only'))
        provenance.append(dict(relative_path=rel,sample_id=sample,source_volume_id=volume,nominal_angle_deg=row['nominal_angle_deg'],coordinate_target_index=ordinal,
            base_transform='author-reported flipud then rot90_ccw',historical_extra_rot180=str(historical).lower(),
            later_rot180_hash_verified=str(later).lower(),final_extra_rot180=str(historical^later).lower(),
            normalized_snapshot_sop_uid=old_uid,normalized_snapshot_file_sha256=row['new_file_sha256'],
            normalized_snapshot_pixel_sha256=row['pixel_data_sha256'],final_sop_uid=str(target.SOPInstanceUID),
            final_file_sha256=digest(payload),final_pixel_sha256=pix,final_bytes=len(payload),
            provenance_basis='Historical QC plus current-to-normalized pixel comparison; not anatomical orientation certification'))
    writecsv(out/'radiograph_provenance.csv',provenance);writecsv(out/'orientation_events.csv',events)
    finalmanual=[]
    for row in manual:
        r=row.copy();volumes=r['source_volume_ids'].split(';');rounds={n for v in volumes for n in finalsets[v]}
        if len(volumes)!=1 and rounds:raise ValueError('Need per-volume final round encoding')
        r['final_orientation_rot180_target_indices']=','.join(map(str,sorted(rounds)))
        r['n_final_orientation_rot180_views']=str(5*len(rounds))
        r['final_orientation_documented_on']='2026-10-16'
        r['final_orientation_evidence']='orientation_events.csv; ../metadata/radiograph_provenance.csv'
        finalmanual.append(r)
    writecsv(out/'manual_qc.csv',finalmanual);writecsv(out/'uid_changes.csv',staged)
    savejson(out/'orientation_verification.json',dict(status='passed',radiographs=len(provenance),
        later_rotated_records=len({r['sample_id'] for r in events}),later_rotated_views=len(events),
        historical_extra_rot180_records=sum(int(r['n_orientation_rot180_views']) for r in manual)//5,
        final_extra_rot180_records=sum(map(len,finalsets.values())),final_extra_rot180_views=5*sum(map(len,finalsets.values())),
        final_source_series=sum(bool(v) for v in finalsets.values()),pixels_changed_by_uid_staging=0,
        unknown_original_operation_times_and_actors=True))

def replay_normalization(root,out,inputs,source,limit=0):
    # Exact event replay uses the published old/new UID mapping; source files are author-held pre-normalization exports.
    rows=readcsv(root/'metadata/dicom_uid_mapping.csv'); rows=rows[:limit] if limit else rows
    checks=[]
    for r in rows:
        original=safe(source,r['relative_path']).read_bytes()
        if digest(original)!=r['old_file_sha256']:raise ValueError('Wrong pre-normalization input')
        ds=pydicom.dcmread(io.BytesIO(original));before=ds.PixelData;decoded=ds.pixel_array.copy()
        ds.SOPInstanceUID=r['new_sop_instance_uid'];ds.SeriesInstanceUID=r['new_series_instance_uid']
        ds.file_meta.MediaStorageSOPInstanceUID=ds.SOPInstanceUID;ds.file_meta.ImplementationClassUID=PYDICOM_IMPLEMENTATION_UID
        ds.file_meta.ImplementationVersionName='PYDICOM_302'
        previous=str(ds.get('DerivationDescription','')).strip();ds.DerivationDescription=(previous+'; ' if previous else '')+NORMALIZATION_NOTE
        for change in json.loads(r['header_repairs_json']):
            tag=int(change['tag'].replace('(','').replace(')','').replace(',','').replace(' ',''),16)
            if change['action']=='omit_malformed_optional_export_field':del ds[tag]
            else:ds.add_new(tag,change['new_vr'],[] if change['new_vr']=='SQ' else change['new_value'])
        payload=serialize(ds);after=pydicom.dcmread(io.BytesIO(payload))
        if before!=after.PixelData or not np.array_equal(decoded,after.pixel_array):raise ValueError('Normalization changed pixels')
        if digest(payload)!=r['new_file_sha256']:raise ValueError('Historical replay not byte-identical')
        p=out/r['relative_path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(payload)
        checks.append(dict(relative_path=r['relative_path'],byte_identical=True,pixel_identical=True))
    savejson(out/'normalization_replay_verification.json',dict(status='passed',files=len(checks),checks=checks,
        scope='Historical event replay; requires pre-normalization exports, which are not claimed to be raw detector frames or included in the public release.'))

def recover_normalized(root,out,inputs):
    """Recover only later-reoriented historical normalized instances, byte-verified."""
    recovered=[]
    for r in readcsv(root/'metadata/dicom_uid_mapping.csv'):
        rel=r['relative_path'];raw=safe(root,rel).read_bytes()
        if digest(raw)==r['new_file_sha256']:continue
        ds=pydicom.dcmread(io.BytesIO(raw))
        ds.PixelData=np.ascontiguousarray(np.rot90(ds.pixel_array,2)).tobytes()
        if digest(ds.PixelData)!=r['pixel_data_sha256']:raise ValueError('Not an explained rot180: '+rel)
        ds.SOPInstanceUID=r['new_sop_instance_uid'];ds.file_meta.MediaStorageSOPInstanceUID=ds.SOPInstanceUID
        ds.DerivationDescription=NORMALIZATION_NOTE
        if 'SourceImageSequence' in ds:del ds.SourceImageSequence
        payload=serialize(ds)
        if digest(payload)!=r['new_file_sha256']:raise ValueError('Historical bytes not exactly recoverable: '+rel)
        p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(payload)
        recovered.append(dict(relative_path=rel,historical_file_sha256=digest(payload),byte_identical=True))
    savejson(out/'historical_snapshot_recovery.json',dict(status='passed',recovered_files=len(recovered),
        checks=recovered,scope='Changed instances only. All other current DICOM files already equal the historical normalization snapshot.'))

def main():
    p=argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument('command',choices=['metadata','coordinates','crop-integrity','partitions','file-tables','dictionary','checksums','orientation','normalization-replay','recover-normalized'])
    p.add_argument('--dataset',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--inputs',type=Path,default=HERE/'inputs');p.add_argument('--hash-mode',choices=['actual','manifest'],default='actual')
    p.add_argument('--workers',type=int,default=3);p.add_argument('--source',type=Path);p.add_argument('--limit',type=int,default=0)
    a=p.parse_args();root=a.dataset.resolve();out=a.out.resolve()
    if out==root or out.is_relative_to(root):p.error('Output must be outside the dataset')
    out.mkdir(parents=True,exist_ok=True)
    if a.command=='file-tables':file_tables(root,out,a.inputs,a.hash_mode,a.workers)
    elif a.command=='checksums':checksums(root,out,a.inputs,a.workers)
    elif a.command=='crop-integrity':crop_integrity(root,out,a.inputs,a.limit)
    elif a.command=='normalization-replay':
        if not a.source:p.error('--source pre-normalization root is required')
        if out==a.source.resolve() or out.is_relative_to(a.source.resolve()):p.error('Output must be outside source exports')
        replay_normalization(root,out,a.inputs,a.source.resolve(),a.limit)
    else:globals()[a.command.replace('-','_')](root,out,a.inputs)
if __name__=='__main__':main()
