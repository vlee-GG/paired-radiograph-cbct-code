# Release curation and verification

This archive supplies the processing/check code supporting the rabbit–mouse data release. The two main entry programs (cropping and five-view retrieval) remain in the accompanying GitHub repository. No Figure 6 plotting program is included here.

## Setup

Python 3.10+; `pip install -r requirements.txt`. Commands write to an output directory **outside** the dataset and do not alter the input dataset.

```bash
python release_tools.py metadata --dataset <release> --out <outputs>/metadata
python release_tools.py coordinates --dataset <release> --out <outputs>/coordinates
python release_tools.py crop-integrity --dataset <release> --out <outputs>/crops
python release_tools.py partitions --dataset <release> --out <outputs>/partitions
python release_tools.py file-tables --dataset <release> --out <outputs>/tables
python release_tools.py dictionary --dataset <release> --out <outputs>/dictionary
python release_tools.py checksums --dataset <release> --out <outputs>/checksums
python release_tools.py orientation --dataset <release> --out <outputs>/orientation
python release_tools.py recover-normalized --dataset <release> --out <outputs>/normalized_inputs
python release_tools.py historical-review --dataset <release> --out <outputs>/historical_review
python -m unittest discover -s tests -v
```

## Inputs and scope

`inputs/release_record_inputs.csv` preserves curated biological identifiers, release selection, retained-crop ordinals and uniquely matched coordinate-target ordinals. Metadata generation computes crop boxes from the coordinate TXT files and source-volume headers, then regenerates counts, shape, angle and clipping fields. Biological provenance cannot be recovered from image intensities and is not inferred.

`inputs/field_definitions.csv` explicitly defines final-instance/event fields and the historical scope of older QC and normalization fields; `dictionary` merges these definitions with the released dictionary.

`inputs/partition_allocation.csv` preserves the published unit identifiers and fold allocation. Connected components are independently rebuilt from shared groups, volumes, specimens and verified animals. The original undocumented fold-randomization procedure is not claimed recovered; this archive replays the explicit allocation and verifies all ten fold pairs.

`file-tables` recomputes actual file hashes by default, parses imaging headers and decodes every radiograph. It preserves curated IDs, roles and notes. DICOM spacing follows the published detector-plane ImagerPixelSpacing (PixelSpacing is a fallback if absent); it is not object-space calibration. NIfTI scaling is read from the effective array proxy; full-precision decimals can differ from the rounded release-table representation. `--hash-mode manifest` is a faster metadata-only alternative that trusts the existing manifest; it is not an independent hash check. `crop-integrity` compares scaled source voxels with each released crop within its quantization tolerance. It tests array-space crop reproduction, not anatomical registration accuracy.

`orientation` compares every current radiograph with its 2026-10-13 normalization-event pixel hash. Later changes are accepted only if the inverse 180-degree rotation matches exactly. Final cumulative counts use **coordinate-target ordinals**, not retained-crop ordinals. It stages distinct deterministic SOP instance UIDs for the 115 later-reoriented images and verifies unchanged pixel bytes/arrays. The original normalization mapping and manual-review date are preserved. Unknown original operation times/actors remain blank; the documentation date is not a new anatomical review date.

`recover-normalized` reconstructs the 115 historical normalized DICOM instances and requires an exact whole-file SHA-256 match. Unchanged instances already match that snapshot. `historical-review` uses the released original display generator and reverses only hash-confirmed later orientation edits in memory. It retains historical invalid scale annotations and original display windows; it neither changes review judgements nor creates valid physical scale bars. Fonts/runtime can affect rendering.

For the earlier UID/VR normalization event:

```bash
python release_tools.py normalization-replay --dataset <release> --source <pre_normalization_exports> --out <outputs>/normalization
```

This replays published old/new identifiers and per-tag repair decisions and requires byte-identical output. The author-held pre-normalization exports are not included in the public release and are not raw detector frames. The public `recover-normalized` command instead recovers the normalized snapshot from the current release.

## Provenance

This is an audited portable implementation of the stated release processing/checks. It does not claim that an undocumented historical pipeline or missing raw acquisition geometry was recovered. The input snapshot provenance and verification results identify what was reproduced. Code: MIT; curated input tables: CC BY 4.0, like the dataset.
