import contextlib, io, tempfile, unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import release_tools as t
import numpy as np
import pydicom
from pydicom.dataset import FileDataset, FileMetaDataset
from pydicom.uid import ExplicitVRLittleEndian

class ScientificChecks(unittest.TestCase):
    def test_coordinate_clipping_and_truncation(self):
        self.assertEqual(t.expected_box([50,100],[5,10],[5,10],(640,640,420)),(0,20,160,110,160,140))
        self.assertEqual(t.expected_box([59.1,100],[5,10],[5,10],(640,640,420)),(0,20,160,120,160,140))
        with self.assertRaises(ValueError): t.expected_box([2000,100],[0,0],[0,0],(640,640,420))

    def test_path_escape_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as d:
            with self.assertRaises(ValueError):t.safe(Path(d),'../outside')

    def fixture(self,root):
        a=np.arange(64,dtype=np.uint16).reshape(8,8);rows=[]
        for angle in t.ANGLES:
            rel=f'data/mouse/g/v/s/s__xray__a{angle:03d}.dcm'
            fm=FileMetaDataset();fm.TransferSyntaxUID=ExplicitVRLittleEndian
            fm.MediaStorageSOPClassUID='1.2.840.10008.5.1.4.1.1.1.3';fm.MediaStorageSOPInstanceUID=f'2.25.{angle}'
            fm.ImplementationClassUID='2.25.999'
            ds=FileDataset(None,{},file_meta=fm,preamble=b'\0'*128)
            ds.SOPClassUID=fm.MediaStorageSOPClassUID;ds.SOPInstanceUID=fm.MediaStorageSOPInstanceUID
            ds.StudyInstanceUID='2.25.111';ds.SeriesInstanceUID=f'2.25.{1000+angle}'
            ds.Rows=8;ds.Columns=8;ds.SamplesPerPixel=1;ds.PhotometricInterpretation='MONOCHROME2'
            ds.BitsAllocated=16;ds.BitsStored=16;ds.HighBit=15;ds.PixelRepresentation=0
            ds.PixelData=a.tobytes();raw=t.serialize(ds)
            rows.append(dict(relative_path=rel,sample_id='s',source_volume_id='v',nominal_angle_deg=str(angle),
                new_sop_instance_uid=str(ds.SOPInstanceUID),new_file_sha256=t.digest(raw),pixel_data_sha256=t.digest(ds.PixelData)))
            ds.PixelData=np.ascontiguousarray(np.rot90(a,2)).tobytes()
            p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.serialize(ds))
        t.writecsv(root/'metadata/dicom_uid_mapping.csv',rows)
        t.writecsv(root/'metadata/metadata.csv',[dict(sample_id='s',source_volume_id='v',crop_index_in_source='1')])
        t.writecsv(root.parent/'release_record_inputs.csv',[dict(sample_id='s',coordinate_target_index='1')])
        t.writecsv(root/'validation/manual_qc.csv',[dict(source_volume_ids='v',orientation_rot180_rounds='',n_orientation_rot180_views='0',reviewed_at='original-review-date')])
        return rows

    def test_final_uid_and_pixels_and_idempotence(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as d:
            root=Path(d)/'data';out=Path(d)/'out';out.mkdir();rows=self.fixture(root)
            t.orientation(root,out,Path(d))
            for r in rows:
                before=pydicom.dcmread(root/r['relative_path']);p=out/'dicom'/r['relative_path'];after=pydicom.dcmread(p)
                self.assertNotEqual(str(before.SOPInstanceUID),str(after.SOPInstanceUID))
                self.assertEqual(after.SOPInstanceUID,after.file_meta.MediaStorageSOPInstanceUID)
                self.assertTrue(np.array_equal(before.pixel_array,after.pixel_array))
                self.assertEqual(str(after.SourceImageSequence[0].ReferencedSOPInstanceUID),r['new_sop_instance_uid'])
                (root/r['relative_path']).write_bytes(p.read_bytes())
            out2=Path(d)/'out2';out2.mkdir();t.orientation(root,out2,Path(d))
            for r in rows:self.assertEqual((out/'dicom'/r['relative_path']).read_bytes(),(out2/'dicom'/r['relative_path']).read_bytes())
            final=t.readcsv(out/'manual_qc.csv')[0]
            self.assertEqual(final['reviewed_at'],'original-review-date')
            self.assertEqual(final['final_orientation_rot180_target_indices'],'1')
            self.assertEqual(final['n_final_orientation_rot180_views'],'5')

    def test_unexplained_pixel_change_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as d:
            root=Path(d)/'data';out=Path(d)/'out';out.mkdir();rows=self.fixture(root)
            p=root/rows[0]['relative_path'];ds=pydicom.dcmread(p);a=ds.pixel_array.copy();a[0,0]+=1
            ds.PixelData=a.tobytes();p.write_bytes(t.serialize(ds))
            with self.assertRaises(ValueError):t.orientation(root,out,Path(d))

    def test_orientation_uses_target_index_after_exclusion(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as d:
            root=Path(d)/'data';out=Path(d)/'out';out.mkdir();self.fixture(root)
            t.writecsv(Path(d)/'release_record_inputs.csv',[dict(sample_id='s',coordinate_target_index='2')])
            t.writecsv(root/'validation/manual_qc.csv',[dict(source_volume_ids='v',orientation_rot180_rounds='2',n_orientation_rot180_views='5',reviewed_at='old')])
            t.orientation(root,out,Path(d))
            p=t.readcsv(out/'radiograph_provenance.csv')[0]
            self.assertEqual(p['historical_extra_rot180'],'true')
            self.assertEqual(p['final_extra_rot180'],'false')
            self.assertEqual(p['coordinate_target_index'],'2')

    def test_checksum_detects_content_change(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as d:
            root=Path(d)/'data';root.mkdir();out=Path(d)/'out';out.mkdir()
            p=root/'a.bin';p.write_bytes(b'known payload')
            (root/'SHA256SUMS.txt').write_text(t.sha(p)+'  a.bin\n',encoding='utf-8')
            t.checksums(root,out,Path(d),1)
            p.write_bytes(b'altered payload')
            with self.assertRaises(ValueError):t.checksums(root,out,Path(d),1)

if __name__=='__main__':unittest.main()
